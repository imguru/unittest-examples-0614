// Google Test를 사용하는 방법
// 1. 다운로드 받는다.
//   $ wget https://github.com/google/googletest/archive/release-1.8.0.tar.gz

// 2. 압축을 해제합니다.
//   $ tar xvf release-1.8.0.tar.gz

// 3. $ cd $GTEST/googletest/scripts/
//    $ ./fuse_gtest_files.py gtest

// 4. 생성된 gtest 디렉토리를 프로젝트로 옮긴다.
// 5. 정적 라이브러리를 빌드한다.
//    $ g++ gtest-all.cc -c -I ../
//    $ g++ gtest_main.cc -c -I ../
//    $ ar rcv gtest.a gtest-all.o gtest_main.o

// 6. $ g++ sample.cpp ./gtest/gtest.a -I. -lpthread -o sample
// => 구성에 대한 부분이 필요하다.
//    Makefile
//--------------------
// Visual Studio - Google Test
// 1. Solution 생성
// 2. gtest static library project
//    src
//      - $GTEST\googletest\src\gtest-all.cc
//      - $GTEST\googletest\src\gtest_main.cc
//    include path
//      - $GTEST\googletest\
//      - $GTEST\googletest\include
// 3. unit test project
//    include path
//      - $GTEST\googletest\include
//    refrence - gtest static library project





// 1. 아래 헤더 파일만 있으면 됩니다.
#include <gtest/gtest.h>
#include <stdio.h>
#include <time.h>

// 2. TestCase class
class CalculatorTest : public ::testing::Test {
public:
	time_t startTime;


	virtual void SetUp() {
			printf("SetUp()\n");
			startTime = time(0);
	}

	virtual void TearDown() {
			printf("TearDown()\n");

			time_t endTime = time(0);
			time_t duration = endTime - startTime;

			ASSERT_TRUE(duration < 2) << "시간 초과: " << duration;
	}
};

// 3. Test Method - 2초를 초과할 경우 테스트는 실패해야 합니다.
TEST_F(CalculatorTest, addTest)
{
	printf("addTest()\n");
	sleep(3);
}














